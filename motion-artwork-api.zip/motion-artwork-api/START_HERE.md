# Start Here — Building This With No Installs and No Downloads

Written assuming you've never built or launched anything like this before,
and that you're often on a computer where you can't install software or
save downloaded files. Every technical word gets explained the first time
it shows up. Follow this top to bottom.

---

## The one thing I need you to check first

Everything below needs you to download **one** small file, **one** time —
the project code itself (a `.zip`, a few hundred KB of text, not a video).
After that, you never need to download anything else again, including the
animated covers themselves.

---

## Part 1: Two ideas that make everything else make sense

**A "repository"** is a project folder that lives on GitHub instead of on
your own computer — reachable from any browser, any device.

**A "Codespace"** is a real computer GitHub lets you borrow, free, that
lives on the internet and that you control entirely through your browser —
editor, terminal, real internet access, without installing anything on the
machine you're sitting at. This is what solves the school-PC problem: the
computer doing the work is GitHub's, not the school's.

---

## Part 2: Get a free GitHub account and grab the code

1. Go to **github.com** → **Sign up**.
2. Download `motion-artwork-api.zip` from this chat.
3. Unzip it (Windows: right-click → **Extract All**; Mac/Chromebook:
   double-click).

---

## Part 3: Put the code on GitHub

1. On github.com, click **+** (top right) → **New repository**. Name it
   anything, click **Create repository**.
2. On the new repo page, click **uploading an existing file**.
3. Open the unzipped folder, select everything inside it, drag it into the
   browser window.
4. Scroll down, click **Commit changes**.

---

## Part 4: Open a Codespace

1. On your repo's page, click the green **Code** button → **Codespaces**
   tab → **Create codespace on main**.
2. Wait 30-60 seconds. A full VS Code editor opens in your browser tab.
   Open a terminal via **Terminal → New Terminal**.

Free tier: 120 hours/month, pauses automatically when idle.

---

## Part 5: Install the project's packages (one-time, per Codespace)

```bash
python3 -m venv venv
source venv/bin/activate
pip install flask requests opencv-python-headless numpy scipy pillow
sudo apt-get update && sudo apt-get install -y ffmpeg
```
`(venv)` at the start of your prompt means it worked. Repeat lines 1-2 (not
3-4) each time you open a fresh Codespace session.

---

## Part 6: Prove it works

```bash
python3 tests/test_pipeline.py
```
Look for `All tests passed.`

```bash
python3 devserver/live_demo.py
```
Takes about 40 seconds. Look for `RESULT: 18/18 checks passed`.

If either shows `FAIL`, copy the red error text back to me.

---

## Part 7: Watch it actually work, with zero downloads

**Set up your address once.** Click the **Ports** tab at the bottom, find
port `9000` (it'll appear once you start the server below), copy the
address shown (looks like `https://something-9000.app.github.dev`), and
right-click that row → **Port Visibility** → **Public** (so a plain
terminal command can reach it, not just a logged-in browser tab).

Then tell the server that address, once, in a file:
```bash
echo 'PUBLIC_BASE_URL=https://YOUR-FORWARDED-ADDRESS' > .env
```
(Replace with what you copied — keep `https://`, drop any trailing slash.
You only do this once per Codespace, even across restarts.)

Start the server:
```bash
python3 devserver/app.py 9000
```
Check the first couple of printed lines — it should say
`PUBLIC_BASE_URL is set: https://...`. If it instead says `NOT set`, the
`.env` step didn't take — redo it and restart. A popup will also offer
**Open in Browser** — that should show a working homepage, not a 404.

**Second terminal**, get a login key:
```bash
source venv/bin/activate
python3 devserver/seed_dev_key.py
```
Copy the key it prints.

**Create a job** (curl works with plain `127.0.0.1` now that `PUBLIC_BASE_URL`
is set — the returned links will be correct regardless of which address you
connect through):
```bash
curl -X POST http://127.0.0.1:9000/v1/motion-artwork/jobs \
  -H "Authorization: Bearer PASTE_YOUR_KEY" \
  -H "Content-Type: application/json" \
  -d '{"release_id":"test1","cover_art_url":"http://127.0.0.1:9000/test-assets/cover.png","tier":"parametric","callback_url":"http://127.0.0.1:9000/v1/health"}'
```
Copy the `job_id` it prints, then check on it a few times, a couple
seconds apart, until `"status"` says `complete`:
```bash
curl http://127.0.0.1:9000/v1/motion-artwork/jobs/PASTE_JOB_ID -H "Authorization: Bearer PASTE_YOUR_KEY"
```
The response includes a `"preview_url"` — a real, clickable
`https://...app.github.dev` link. **Paste it into a new browser tab and the
animated cover just plays, no download button anywhere.** That was the
actual fix for the school-PC problem: the video was never something you
needed to save, only something you needed to *watch*.

---

## Part 8: What to do with this once it works

Bookmark your Codespace at github.com/codespaces — reachable from any
school, library, or home computer with just a browser. From here, see
`README.md` and `API_GUIDE.md` for what "a real product" needs next; none
of it is urgent before you've shown this to people and gotten real interest.

---

## Plan B: zero downloads, ever

If even the one small zip download in Part 2 is blocked: do that single
step from any other device you have occasional access to (phone, library
computer, a friend's laptop) just to get the code onto GitHub once. Every
step after Part 3 never needs a download again, on any computer, forever.
