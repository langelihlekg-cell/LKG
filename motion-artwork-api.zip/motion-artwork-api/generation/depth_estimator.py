"""
Depth estimation for the motion-artwork pipeline.

Design: one interface, two implementations.
  - ClassicalDepthEstimator: CPU-only, no ML weights, runs anywhere.
  - DepthAnythingV2Estimator: the real production model. Same interface, so
    swapping it in is a one-line change in render.py.
"""
from __future__ import annotations
import numpy as np
import cv2


class DepthEstimator:
    def estimate(self, image_rgb: np.ndarray) -> np.ndarray:
        raise NotImplementedError


class ClassicalDepthEstimator(DepthEstimator):
    """
    CPU stand-in using:
      1. Spectral-residual saliency (Hou & Zhang, 2007) — implemented directly
         with numpy's FFT, NOT via cv2.saliency (that module only ships in
         opencv-contrib-python(-headless), not the plain opencv-python-headless
         this project installs).
      2. A mild center-weighted prior.
      3. Local contrast (Laplacian energy) as a secondary "in-focus = close" cue.
    """

    def __init__(self, saliency_weight=0.55, center_weight=0.20, contrast_weight=0.25):
        self.saliency_weight = saliency_weight
        self.center_weight = center_weight
        self.contrast_weight = contrast_weight

    @staticmethod
    def _spectral_residual_saliency(gray: np.ndarray, work_size: int = 64) -> np.ndarray:
        h, w = gray.shape
        small = cv2.resize(gray, (work_size, work_size), interpolation=cv2.INTER_AREA).astype(np.float64)

        f = np.fft.fft2(small)
        amplitude = np.abs(f)
        phase = np.angle(f)
        log_amp = np.log(amplitude + 1e-8)
        avg_log_amp = cv2.blur(log_amp, (3, 3))
        residual = log_amp - avg_log_amp

        reconstructed = np.fft.ifft2(np.exp(residual + 1j * phase))
        sal_small = np.abs(reconstructed) ** 2
        sal_small = cv2.GaussianBlur(sal_small.astype(np.float32), (0, 0), sigmaX=2.0)

        sal = cv2.resize(sal_small, (w, h), interpolation=cv2.INTER_LINEAR)
        sal = (sal - sal.min()) / (sal.max() - sal.min() + 1e-8)
        return sal.astype(np.float32)

    def estimate(self, image_rgb: np.ndarray) -> np.ndarray:
        h, w = image_rgb.shape[:2]
        bgr = cv2.cvtColor(image_rgb, cv2.COLOR_RGB2BGR)
        gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)

        sal = self._spectral_residual_saliency(gray)

        yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
        cy, cx = h / 2.0, w / 2.0
        dist = np.sqrt(((yy - cy) / (h / 2)) ** 2 + ((xx - cx) / (w / 2)) ** 2)
        center_prior = np.clip(1.0 - dist, 0, 1)

        gray_f = gray.astype(np.float32)
        lap = cv2.Laplacian(gray_f, cv2.CV_32F, ksize=3)
        lap_energy = cv2.GaussianBlur(np.abs(lap), (0, 0), sigmaX=max(w, h) * 0.01)
        lap_energy = (lap_energy - lap_energy.min()) / (lap_energy.max() - lap_energy.min() + 1e-8)

        depth = (
            self.saliency_weight * sal
            + self.center_weight * center_prior
            + self.contrast_weight * lap_energy
        )
        depth = cv2.GaussianBlur(depth, (0, 0), sigmaX=max(w, h) * 0.006)
        depth = (depth - depth.min()) / (depth.max() - depth.min() + 1e-8)
        return depth.astype(np.float32)


class DepthAnythingV2Estimator(DepthEstimator):
    def __init__(self, model_name: str = "depth-anything/Depth-Anything-V2-Small-hf"):
        from transformers import pipeline
        self.pipe = pipeline(task="depth-estimation", model=model_name)

    def estimate(self, image_rgb: np.ndarray) -> np.ndarray:
        from PIL import Image
        pil_img = Image.fromarray(image_rgb)
        result = self.pipe(pil_img)
        depth = np.array(result["depth"], dtype=np.float32)
        depth = (depth - depth.min()) / (depth.max() - depth.min() + 1e-8)
        return depth
