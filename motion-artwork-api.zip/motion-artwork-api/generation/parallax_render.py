from __future__ import annotations
import os
import subprocess
import shutil
import numpy as np
import cv2

PRODUCTION_SQUARE = (3840, 3840)
PRODUCTION_VERTICAL = (2048, 2732)       # Apple 3:4
DEMO_SQUARE = (480, 480)
DEMO_VERTICAL = (480, 640)

# Spotify Canvas: 9:16, verified against Spotify's current published spec
# (720-1080px tall; 1080x1920 is their "recommended" size, 720x1280 is the
# documented floor). Single deliverable, not a pair — Canvas has no square
# or 3:4 variant, only this one.
CANVAS_VERTICAL = (1080, 1920)
CANVAS_VERTICAL_DEMO = (360, 640)


def compose_vertical_canvas(square_rgb: np.ndarray, target_w: int, target_h: int,
                             feather_frac: float = 0.10) -> np.ndarray:
    """Composites the square source onto a blurred, extended background for
    a taller target. `feather_frac` softens the seam between the sharp
    foreground and blurred background with a vertical alpha ramp — a hard
    paste (no feathering) was invisible at 3:4, where the foreground fills
    most of the frame, but produced an obvious hard band at 9:16, where the
    background margin is much larger. Confirmed by rendering both and
    actually looking at the result, not just checking dimensions."""
    sq_h, sq_w = square_rgb.shape[:2]
    scale = max(target_w / sq_w, target_h / sq_h)
    bg = cv2.resize(square_rgb, (int(sq_w * scale) + 1, int(sq_h * scale) + 1))
    by, bx = bg.shape[0], bg.shape[1]
    top = (by - target_h) // 2
    left = (bx - target_w) // 2
    bg = bg[top:top + target_h, left:left + target_w]
    # sigma scaled by the TALLER of the two dims, not just width -- at
    # extreme aspect ratios (9:16) the background is a heavy crop of the
    # source and a width-only blur radius left a visible ghost of the
    # foreground shape showing through. Confirmed by rendering and looking.
    bg = cv2.GaussianBlur(bg, (0, 0), sigmaX=max(target_w, target_h) * 0.05)
    bg = (bg.astype(np.float32) * 0.45)

    fg_w = target_w
    fg_h = int(sq_h * (fg_w / sq_w))
    fg = cv2.resize(square_rgb, (fg_w, fg_h)).astype(np.float32)
    canvas = bg.copy()
    y0 = (target_h - fg_h) // 2

    feather = max(2, int(fg_h * feather_frac))
    ramp = np.linspace(0.0, 1.0, feather, dtype=np.float32)
    alpha = np.ones(fg_h, dtype=np.float32)
    alpha[:feather] = ramp
    alpha[-feather:] = ramp[::-1]
    alpha = alpha[:, None, None]  # broadcast over width and channels

    if y0 >= 0:
        region = canvas[y0:y0 + fg_h, 0:fg_w]
        canvas[y0:y0 + fg_h, 0:fg_w] = fg * alpha + region * (1 - alpha)
    else:
        crop_top = -y0
        fg_crop = fg[crop_top:crop_top + target_h, :]
        alpha_crop = alpha[crop_top:crop_top + target_h]
        region = canvas[0:target_h, 0:fg_w]
        canvas[0:target_h, 0:fg_w] = fg_crop * alpha_crop + region * (1 - alpha_crop)
    return np.clip(canvas, 0, 255).astype(np.uint8)


def motion_concentration_mask(h: int, w: int, center_radius: float = 0.3,
                               falloff: float = 0.45) -> np.ndarray:
    """0 inside `center_radius` of the frame center, ramping up to 1 over the
    next `falloff` distance toward the edges. Multiplying the parallax
    offset by this keeps wherever the main subject usually sits (the
    center, by composition convention) essentially still, and concentrates
    the visible wobble into the periphery instead -- matching reference
    footage where the portrait itself barely moves and the motion reads as
    isolated to the edges/background rather than the whole frame swimming."""
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    cy, cx = h / 2.0, w / 2.0
    dist = np.sqrt(((yy - cy) / (h / 2)) ** 2 + ((xx - cx) / (w / 2)) ** 2)
    mask = (dist - center_radius) / max(falloff, 1e-6)
    return np.clip(mask, 0.0, 1.0).astype(np.float32)


def render_frame(source_rgb: np.ndarray, depth: np.ndarray, phase: float,
                  parallax_gain: float, zoom_gain: float,
                  motion_mask: np.ndarray | None = None) -> np.ndarray:
    h, w = source_rgb.shape[:2]
    cy, cx = h / 2.0, w / 2.0
    offset_x = parallax_gain * w * np.sin(phase)
    offset_y = parallax_gain * h * 0.35 * np.sin(phase + np.pi / 2)
    zoom = 1.0 + zoom_gain * (1 - np.cos(phase)) / 2.0

    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    map_x = cx + (xx - cx) / zoom
    map_y = cy + (yy - cy) / zoom
    weight = depth if motion_mask is None else depth * motion_mask
    map_x = map_x + offset_x * weight
    map_y = map_y + offset_y * weight

    return cv2.remap(
        source_rgb, map_x.astype(np.float32), map_y.astype(np.float32),
        interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT101,
    )


def render_frame_sequence(source_rgb: np.ndarray, depth: np.ndarray, n_frames: int,
                           parallax_gain: float = 0.018, zoom_gain: float = 0.045):
    for i in range(n_frames):
        phase = 2 * np.pi * i / n_frames
        yield render_frame(source_rgb, depth, phase, parallax_gain, zoom_gain)


# --- tier-specific "look" ------------------------------------------------
# Parametric = plain parallax (as before). Stylized and cinematic layer on
# real, distinct post-processing rather than just charging more for the
# same pixels — all classical/local, no paid generative API required.

TIER_MOTION_PARAMS = {
    # Reference footage (The Weeknd "After Hours", Apple Motion) shows
    # near-static framing — the movement is almost entirely in shifting
    # light color, not camera pan/zoom. Cut parallax down further on top of
    # that (overall "wobble" was reported as too strong even for parametric),
    # and center_radius/falloff concentrate what's left away from the main
    # subject and toward the edges instead of the whole frame moving.
    "parametric": {"parallax_gain": 0.011, "zoom_gain": 0.028, "center_radius": 0.25, "falloff": 0.55},
    "stylized":   {"parallax_gain": 0.009, "zoom_gain": 0.022, "center_radius": 0.32, "falloff": 0.45},
    "cinematic":  {"parallax_gain": 0.007, "zoom_gain": 0.016, "center_radius": 0.38, "falloff": 0.40},
}


def _vignette_mask(h: int, w: int, strength: float) -> np.ndarray:
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    cy, cx = h / 2.0, w / 2.0
    dist = np.sqrt(((yy - cy) / (h / 2)) ** 2 + ((xx - cx) / (w / 2)) ** 2)
    mask = 1.0 - strength * np.clip(dist - 0.5, 0, None) / 0.5
    return np.clip(mask, 1 - strength, 1.0).astype(np.float32)


# Measured directly off a real Apple Motion reference clip (After Hours):
# frame-mean R-B swings from about -23 (blue wash) to +38 (red/warm wash)
# and back, cycling roughly every 1-2s -- a moving colored-light effect,
# not a fixed grade. A static split-tone (the old approach here) produces
# a flat R-B around +15 for the entire clip and reads as "just tinted
# yellow" by comparison -- confirmed by measuring our own prior output.
_LIGHT_WASH_KEYFRAMES = [
    (0.78, 0.86, 1.30),   # cool blue wash
    (1.42, 0.88, 0.72),   # warm red/amber wash
    (1.14, 1.12, 1.05),   # brighter, near-neutral flash
]


def _light_wash(frame: np.ndarray, phase: float, strength: float) -> np.ndarray:
    """Cycles smoothly through the keyframes above as `phase` sweeps 0->2*pi
    -- same phase variable the camera motion already uses, so the color
    cycle and the loop point line up perfectly with zero extra bookkeeping."""
    n = len(_LIGHT_WASH_KEYFRAMES)
    pos = (phase / (2 * np.pi)) * n
    i0 = int(np.floor(pos)) % n
    i1 = (i0 + 1) % n
    t = pos - np.floor(pos)
    ease = (1 - np.cos(t * np.pi)) / 2.0  # ease in/out, not a linear crossfade
    k0 = np.array(_LIGHT_WASH_KEYFRAMES[i0])
    k1 = np.array(_LIGHT_WASH_KEYFRAMES[i1])
    mix = k0 + (k1 - k0) * ease
    gains = (1.0 + (mix - 1.0) * strength).astype(np.float32)
    f = frame.astype(np.float32) * gains[None, None, :]
    return np.clip(f, 0, 255).astype(np.uint8)


def _film_grain(frame: np.ndarray, amount: float, rng: np.random.Generator) -> np.ndarray:
    noise = rng.normal(0, amount, frame.shape[:2]).astype(np.float32)
    out = frame.astype(np.float32) + noise[..., None]
    return np.clip(out, 0, 255).astype(np.uint8)


def _depth_of_field_blur(frame: np.ndarray, depth: np.ndarray, max_sigma: float) -> np.ndarray:
    """Blurs regions in proportion to how FAR they are (low depth = far =
    more blur), producing a genuine shallow-depth-of-field look — the
    foreground subject stays sharp, the background falls away softly."""
    blurred = cv2.GaussianBlur(frame, (0, 0), sigmaX=max_sigma)
    sharpness = depth[..., None]  # depth=1 near -> sharp, depth=0 far -> blurred
    out = frame.astype(np.float32) * sharpness + blurred.astype(np.float32) * (1 - sharpness)
    return np.clip(out, 0, 255).astype(np.uint8)


def apply_tier_look(frame: np.ndarray, depth: np.ndarray, phase: float, tier: str,
                     rng: np.random.Generator) -> np.ndarray:
    if tier == "stylized":
        frame = _light_wash(frame, phase, strength=0.55)
        h, w = frame.shape[:2]
        frame = (frame.astype(np.float32) * _vignette_mask(h, w, 0.28)[..., None]).astype(np.uint8)
        frame = _film_grain(frame, amount=4.0, rng=rng)
        return frame
    if tier == "cinematic":
        frame = _depth_of_field_blur(frame, depth, max_sigma=6.0)
        frame = _light_wash(frame, phase, strength=0.85)
        h, w = frame.shape[:2]
        frame = (frame.astype(np.float32) * _vignette_mask(h, w, 0.38)[..., None]).astype(np.uint8)
        frame = _film_grain(frame, amount=5.0, rng=rng)
        return frame
    return frame  # parametric: unchanged


def render_frame_sequence_for_tier(source_rgb: np.ndarray, depth: np.ndarray, n_frames: int, tier: str):
    params = TIER_MOTION_PARAMS.get(tier, TIER_MOTION_PARAMS["parametric"])
    h, w = source_rgb.shape[:2]
    mask = motion_concentration_mask(h, w, params["center_radius"], params["falloff"])
    rng = np.random.default_rng(12345)  # fixed seed: deterministic grain, not flicker-random per frame
    for i in range(n_frames):
        phase = 2 * np.pi * i / n_frames
        frame = render_frame(source_rgb, depth, phase, params["parallax_gain"], params["zoom_gain"], mask)
        yield apply_tier_look(frame, depth, phase, tier, rng)


def encode_frames_to_video(frame_paths_dir: str, fps: int, n_frames: int, out_path: str,
                            codec: str = "h264", bitrate_mbps: float = 8.0) -> None:
    if codec == "h264":
        cmd = [
            "ffmpeg", "-y", "-framerate", str(fps),
            "-i", os.path.join(frame_paths_dir, "%06d.png"),
            "-frames:v", str(n_frames), "-an",
            "-c:v", "libx264", "-preset", "medium", "-pix_fmt", "yuv420p",
            "-b:v", f"{bitrate_mbps}M", "-minrate", f"{bitrate_mbps}M",
            "-maxrate", f"{bitrate_mbps}M", "-bufsize", f"{bitrate_mbps * 0.5}M",
            "-x264-params", "nal-hrd=cbr:force-cfr=1",
            out_path,
        ]
    elif codec == "prores":
        cmd = [
            "ffmpeg", "-y", "-framerate", str(fps),
            "-i", os.path.join(frame_paths_dir, "%06d.png"),
            "-frames:v", str(n_frames), "-an",
            "-c:v", "prores_ks", "-profile:v", "3", "-pix_fmt", "yuv422p10le",
            "-vendor", "apl0", "-qscale:v", "9",
            out_path,
        ]
    else:
        raise ValueError(f"unknown codec {codec}")

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(f"ffmpeg failed:\n{result.stderr[-2000:]}")


def render_deliverable(source_rgb: np.ndarray, depth_estimator, target_w: int, target_h: int,
                        duration_s: float, fps: int, out_path: str, codec: str,
                        bitrate_mbps: float, is_vertical: bool, tmp_dir: str, tier: str = "parametric") -> str:
    if is_vertical:
        canvas = compose_vertical_canvas(source_rgb, target_w, target_h)
    else:
        canvas = cv2.resize(source_rgb, (target_w, target_h))

    depth = depth_estimator.estimate(canvas)
    n_frames = int(round(duration_s * fps))

    frame_dir = os.path.join(tmp_dir, "frames_" + ("v" if is_vertical else "s"))
    os.makedirs(frame_dir, exist_ok=True)
    for i, frame in enumerate(render_frame_sequence_for_tier(canvas, depth, n_frames, tier)):
        cv2.imwrite(os.path.join(frame_dir, f"{i:06d}.png"),
                    cv2.cvtColor(frame, cv2.COLOR_RGB2BGR))

    encode_frames_to_video(frame_dir, fps, n_frames, out_path, codec, bitrate_mbps)
    shutil.rmtree(frame_dir, ignore_errors=True)
    return out_path


def render_pair(source_image_path: str, out_dir: str, depth_estimator,
                 duration_s: float = 12.0, fps: int = 24, codec: str = "h264",
                 bitrate_mbps: float = 8.0, dims=(PRODUCTION_SQUARE, PRODUCTION_VERTICAL),
                 tier: str = "parametric") -> dict:
    os.makedirs(out_dir, exist_ok=True)
    tmp_dir = os.path.join(out_dir, "_tmp")
    os.makedirs(tmp_dir, exist_ok=True)

    src = cv2.imread(source_image_path)
    src = cv2.cvtColor(src, cv2.COLOR_BGR2RGB)

    square_dims, vertical_dims = dims
    ext = "mov" if codec == "prores" else "mp4"
    square_path = os.path.join(out_dir, f"square_1x1.{ext}")
    vertical_path = os.path.join(out_dir, f"vertical_3x4.{ext}")

    render_deliverable(src, depth_estimator, *square_dims, duration_s, fps,
                        square_path, codec, bitrate_mbps, is_vertical=False, tmp_dir=tmp_dir, tier=tier)
    render_deliverable(src, depth_estimator, *vertical_dims, duration_s, fps,
                        vertical_path, codec, bitrate_mbps, is_vertical=True, tmp_dir=tmp_dir, tier=tier)

    shutil.rmtree(tmp_dir, ignore_errors=True)
    return {"square_1x1": square_path, "vertical_3x4": vertical_path}
