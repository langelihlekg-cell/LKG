# Getting Started — From Zero to Running This Project

**On a restricted computer (e.g. a school PC) that won't let you install
things or download files?** Use `START_HERE.md` instead. This guide
assumes a normal personal computer where you can install Python etc. freely.

Written for: you've never developed or launched an API before. Every command
below is something you type into a terminal and press Enter — nothing here
assumes prior coding experience.

---

## 0. What you're actually building, in one paragraph

An **API** is a program that sits and waits for other programs to send it
requests, and sends back answers. This project has one that takes an album
cover image, generates a short looping animated version of it, checks that
the animation meets Apple's technical rules, and hands the result back. A
**server** is the running copy of that program. You'll run it on your own
computer (`localhost`) and talk to it yourself, the same way a real
distributor's system eventually would.

---

## 1. Install the tools you need (one-time setup)

**VS Code** — download from https://code.visualstudio.com.

**Python 3.11+** — check with `python3 --version` (Mac/Linux) or
`python --version` (Windows). If missing: Mac → `brew install python3` or
https://python.org/downloads; Windows → https://python.org/downloads,
**check "Add Python to PATH"** during install; Linux →
`sudo apt install python3 python3-venv`.

**ffmpeg** — Mac: `brew install ffmpeg`. Windows: `winget install ffmpeg`.
Linux: `sudo apt install ffmpeg`. Verify with `ffmpeg -version`.

You do **not** need Docker, Postgres, or Redis for anything in this guide.

---

## 2. Get the project onto your computer

1. Download `motion-artwork-api.zip` from the chat and unzip it.
2. Open VS Code → **File → Open Folder** → select the unzipped folder.
3. **Terminal → New Terminal** in the top menu.

---

## 3. Set up an isolated Python environment

```bash
python3 -m venv venv
source venv/bin/activate          # Windows (cmd): venv\Scripts\activate.bat
                                   # Windows (PowerShell): venv\Scripts\Activate.ps1
pip install flask requests opencv-python-headless numpy scipy pillow
```
You'll know the venv is active because your prompt starts with `(venv)`.

---

## 4. Run the automated test suite

```bash
python3 tests/test_pipeline.py
```
Generates an animation and checks it against Apple's actual rules, no
server involved. Look for `All tests passed.`

---

## 5. Run the full live demo

```bash
python3 devserver/live_demo.py
```
Starts two small servers, creates a real job over HTTP, waits for it to
render and get checked, downloads the result back, confirms a signed
notification was delivered — takes about 40 seconds. Look for
`RESULT: 18/18 checks passed`.

---

## 6. Run it yourself and poke at it with real requests

**Terminal 1:**
```bash
echo 'PUBLIC_BASE_URL=http://127.0.0.1:9000' > .env
python3 devserver/app.py 9000
```
Leave running — it should print `PUBLIC_BASE_URL is set: ...` near the top.

**Terminal 2** (new terminal, then `source venv/bin/activate`):
```bash
python3 devserver/seed_dev_key.py
```
Copy the key it prints. Then:
```bash
curl -X POST http://127.0.0.1:9000/v1/motion-artwork/jobs \
  -H "Authorization: Bearer PASTE_YOUR_KEY" \
  -H "Content-Type: application/json" \
  -d '{"release_id":"my-first-test","cover_art_url":"http://127.0.0.1:9000/test-assets/cover.png","tier":"parametric","callback_url":"http://127.0.0.1:9000/v1/health"}'
```
Copy the `job_id` from the response, then:
```bash
curl http://127.0.0.1:9000/v1/motion-artwork/jobs/PASTE_JOB_ID \
  -H "Authorization: Bearer PASTE_YOUR_KEY"
```
Run that again a few times until `"status"` says `complete`, then open the
`preview_url` from the response in your browser — the animation just plays.

To stop the servers: click into their terminal and press `Ctrl+C`.

---

## 7. A guided tour

- **`generation/`** — turns a flat image into a moving one.
- **`qc/`** — checks output against Apple's technical rules automatically.
- **`devserver/`** — the version of the API you just ran: real, but built
  from simple parts so it runs with no extra setup.
- **`api/`** — the same API rebuilt on production-grade parts (Postgres,
  Celery) — what you'd actually deploy.
- **`API_GUIDE.md`** — how the finished system is meant to behave.
- **`tests/`** and **`devserver/live_demo.py`** — automated proof things work.

---

## 8. From "runs on my laptop" to "a real product"

1. **A place to run it 24/7** — a small cloud server (~$5-6/month).
2. **A real database and job queue** — Postgres/Redis, both have cheap
   managed hosting (Neon/Supabase, Upstash).
3. **GPU access for the real depth model** — rent by the hour (RunPod,
   Modal), or start free on Google Colab.
4. **File storage** — Cloudflare R2, free tier covers early testing.
5. **Actually talking to a distributor and Apple** — the step nobody can
   script for you.

---

## 9. Troubleshooting

- **"command not found: python3"** — Python isn't installed/on PATH.
- **`pip install` fails with a permissions error** — venv probably isn't
  activated; check for `(venv)` in your prompt.
- **"Address already in use"** — something's already using that port;
  close that terminal or use a different port number.
- **`ffmpeg: command not found`** — revisit step 1.
- **Links say `localhost` and won't open** — make sure the `.env` file in
  step 6 is set and the server printed `PUBLIC_BASE_URL is set`.
- **Nothing above matches** — copy the full error text back into chat.
