# iOS 26's MPMediaItemAnimatedArtwork — what it actually changes

## What it is, confirmed against Apple's own developer docs

`MPMediaItemAnimatedArtwork` is real, shipped in iOS 26. Any app that plays
audio and sets "Now Playing" info — not just Apple Music — can supply
animated lock-screen artwork via `MPNowPlayingInfoCenter`. That means
Spotify, Tidal, YouTube Music, every podcast app, audiobook apps, DJ apps,
internet radio — anything with a Now Playing screen — now has a reason to
want exactly the asset this project already produces.

**This is the actual, material change:** the customer list is no longer
"music distributors who submit to Apple Music's catalog." It's any iOS app
with a Now Playing screen. That's a much bigger market than the one all the
distributor outreach so far has been validating against.

## The technical bar — and it's lower than what we already meet

Pulled directly from Apple's current documentation
(`developer.apple.com/documentation/mediaplayer/providing-animated-artwork-for-media-items`):

| Requirement | Apple Music catalog submission (Album Motion Guidelines) | MPMediaItemAnimatedArtwork (this API) | What we already produce |
|---|---|---|---|
| Aspect ratios | 1:1 and 3:4 | 1:1 and 3:4 (same two keys) | 1:1 and 3:4 — exact match |
| Resolution | 3840×3840 / 2048×2732, mandatory | Any size, as long as aspect ratio matches | 3840×3840 at full-res |
| Codec/bitrate | ProRes or 45–100 Mbps H.264, mandatory | No mandate — anything `AVPlayerLayer` can play | H.264, well within range |
| Frame rate | Exactly 23.976/24/25/29.97/30fps | Anything up to 60fps | 24fps |
| Duration & looping | 8–35s, seamless loop | <30s preferred, must loop without a visible jump/fade | Same seamless-loop design already built and QC-checked |
| Delivery | One-time submission into Apple's catalog pipeline | App supplies a **local file URL on demand**, lazily, when the system actually needs it (30s timeout) | — this is the one real architectural difference, see below |

Nothing about our renderer or QC suite needs to change technically — the
Apple Music pipeline we already built is strictly *more* demanding than
what this new API requires. We already over-qualify.

## The one real difference: delivery model, not asset format

This isn't a submission pipeline — it's a runtime callback. The consuming
app's own code returns a local file URL inside an async closure
(`videoAssetFileURLRequestHandler`) only when the system is actually about
to display the artwork, and is expected to fetch-and-cache it itself.
That maps directly onto the API already built here: an app's closure can
simply call our existing `GET` asset URL, save it locally, and hand back
the path. No new endpoint needed — just a different *caller*.

```swift
// Inside the consuming app's own code — illustrative, matches Apple's
// documented pattern exactly, with our API as the source.
let squareAnimatedArtwork = MPMediaItemAnimatedArtwork(
    artworkID: release.id,
    previewImageRequestHandler: { _ in
        release.cachedFirstFrame  // served instantly from local cache
    },
    videoAssetFileURLRequestHandler: { _ in
        do {
            let localURL = Self.cacheDir.appendingPathComponent("\(release.id)_square.mp4")
            if !FileManager.default.fileExists(atPath: localURL.path) {
                // This GET is us — the square_1x1 URL returned once a
                // /v1/motion-artwork/jobs job completes.
                let data = try await URLSession.shared.data(from: release.squareAssetURL).0
                try data.write(to: localURL)
            }
            return localURL
        } catch {
            return nil  // system falls back to static artwork
        }
    }
)
MPNowPlayingInfoCenter.default().nowPlayingInfo = [
    MPNowPlayingInfoProperty1x1AnimatedArtwork: squareAnimatedArtwork,
    MPNowPlayingInfoProperty3x4AnimatedArtwork: tallAnimatedArtwork,
    // ...existing metadata keys
]
```

## What's actually worth doing about this

1. **Reposition, cheaply, right now.** `API_REFERENCE_FOR_DISTRIBUTORS.md`
   and the motion.canvas site currently speak only to distributors
   submitting into Apple Music's catalog. Add a section (or a whole
   second page) speaking directly to app developers who want Now Playing
   support — same API, different pitch, zero new engineering.
2. **This is a genuine timing window, not just a feature.** iOS 26 is
   months old. Every app with a Now Playing screen is currently deciding
   whether to build this themselves or not — most won't have an existing
   animated-asset pipeline. Worth running the same kind of direct outreach
   already done with distributors, but aimed at a few smaller podcast or
   niche music app teams, to see if this angle gets a faster "yes" than
   the distributor pitch has.
3. **A thin SDK is a real future option, not a today one.** The code
   sample above is genuinely all an app needs — eventually packaging it as
   a drop-in Swift package ("animated Now Playing art in an afternoon")
   would be a strong pitch, but it's new scope, not a prerequisite. Test
   the positioning with the API as it already exists before building that.
4. **Verified against our own output, not just asserted.** Rendered a real
   12-second pair and checked it against every documented requirement
   directly: aspect ratio exactly 1.0 and 0.75, 24fps (well under the
   60fps ceiling), H.264 (AVPlayerLayer-compatible by construction), no
   audio track, and the seamless-loop check scored a wrap-step ratio of
   0.01–0.02 (2.0 is the failure line — this is about as clean a loop as
   the metric can show). Every box ticks at demo resolution. One real
   scaling note: that render was ~8.7MB at demo resolution for 12s: a
   full 3840×3840 production render will land considerably larger, which
   matters for an app fetching this on-demand rather than Apple Music's
   one-time catalog submission — no documented hard limit, but worth
   keeping an eye on for apps on constrained connections.
   The one thing this *can't* confirm from here: actual behavior inside
   a real iOS app calling the live API on a real device — that still
   needs a real test app, the same way the Apple Music pipeline's actual
   submission ultimately needs a real distributor account.
