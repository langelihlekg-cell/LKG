-- Adds Stripe billing support. Run after 001_init.sql.
ALTER TABLE orgs ADD COLUMN stripe_customer_id TEXT;
ALTER TABLE orgs ADD COLUMN billing_status TEXT NOT NULL DEFAULT 'good';
    -- 'good' | 'past_due' -- check this in auth before allowing new jobs
    -- once you wire up the invoice.payment_failed webhook handler.
CREATE INDEX idx_orgs_stripe_customer ON orgs(stripe_customer_id);
