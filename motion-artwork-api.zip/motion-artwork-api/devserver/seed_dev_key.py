#!/usr/bin/env python3
"""
Creates a dev org + API key so you can test the API by hand (with curl, or
a tool like Postman) instead of only through live_demo.py.

Run: python3 devserver/seed_dev_key.py
"""
import sys
import os
import uuid
import hashlib

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import db

db.init_db(fresh=False)  # never wipes existing orgs/keys
org = db.create_org("My Org")
raw_key = uuid.uuid4().hex + uuid.uuid4().hex
db.create_api_key(org["id"], hashlib.sha256(raw_key.encode()).hexdigest())

print(f"Org created: {org['id']}")
print("Your API key (copy this now -- it will not be shown again):")
print(raw_key)
