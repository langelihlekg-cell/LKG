"""
Runnable reference implementation of the API contract, for environments
without network access to install fastapi/celery/postgres/redis (like the
original build sandbox). Same request/response shapes as api/main.py. Run
standalone:

    python3 devserver/app.py [port]

This is a same-CONTRACT stand-in, not a production server: Flask's dev
server and a Python thread pool are fine for proving the logic works, not
for real traffic. api/ (FastAPI + Celery + Postgres) remains the documented
production path — swap to it once you have network access to install those
packages and run real Postgres/Redis.
"""
import os
import sys
import json
import hashlib
import uuid
import threading
import queue
import datetime
import shutil

from flask import Flask, request, jsonify, send_from_directory

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "generation"))
sys.path.insert(0, os.path.join(ROOT, "qc"))
sys.path.insert(0, ROOT)


def _load_dotenv(path: str):
    """Tiny hand-rolled .env loader (no extra package needed) — reads
    KEY=VALUE lines and applies them if that key isn't already set in the
    real environment. Set PUBLIC_BASE_URL once in a file instead of typing
    it as a shell prefix every time you start the server — that proved
    fragile in practice (it's easy to forget on a restart)."""
    if not os.path.exists(path):
        return
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            key, value = key.strip(), value.strip().strip('"').strip("'")
            os.environ.setdefault(key, value)


_load_dotenv(os.path.join(ROOT, ".env"))

import requests
import cv2
from depth_estimator import ClassicalDepthEstimator
from parallax_render import (
    render_pair, render_deliverable, compose_vertical_canvas, DEMO_SQUARE, DEMO_VERTICAL,
    PRODUCTION_SQUARE, PRODUCTION_VERTICAL, CANVAS_VERTICAL, CANVAS_VERTICAL_DEMO,
)
from qc_suite import run_qc_suite, run_qc_suite_single, CONFIG as QC_CONFIG
from api.pricing import price_for_tier, QC_ONLY_PRICE_USD

import db
from webhook_utils import sign_payload

# --- config -----------------------------------------------------------
USE_FULL_RES = os.environ.get("MOTION_ARTWORK_FULL_RES", "0") == "1"
DIMS = (PRODUCTION_SQUARE, PRODUCTION_VERTICAL) if USE_FULL_RES else (DEMO_SQUARE, DEMO_VERTICAL)
RENDER_DURATION_S = 12.0 if USE_FULL_RES else 3.0
# 24fps regardless of resolution mode — Apple only accepts 23.976/24/25/
# 29.97/30 fps (see qc_suite.py's check_frame_rate). This used to be 12fps
# for the fast demo path, which rendered fine but would always fail the
# frame-rate check now that qc_suite.py checks for it.
RENDER_FPS = 24
RENDER_BITRATE_MBPS = 60.0 if USE_FULL_RES else 6.0

# Spotify Canvas: one 9:16 deliverable, not an Apple-style pair. Verified
# spec: 3-8s, no audio, MP4 — much less strict than Apple's, see
# IOS26_ANIMATED_ARTWORK_OPPORTUNITY.md and the renderer's CANVAS_VERTICAL.
CANVAS_DIMS = CANVAS_VERTICAL if USE_FULL_RES else CANVAS_VERTICAL_DEMO
CANVAS_DURATION_S = 6.0
CANVAS_BITRATE_MBPS = 6.0 if USE_FULL_RES else 3.0

ASSETS_DIR = os.path.join(HERE, "storage")
os.makedirs(ASSETS_DIR, exist_ok=True)

# Auto-detecting the public-facing address from the incoming request works
# on a plain server but NOT reliably behind Codespaces' port-forwarding
# proxy, which was found (via a real user hitting it) to rewrite the host
# info to "localhost" regardless of the actual forwarded address used. Set
# this once (via a .env file, loaded above) and every returned URL uses it
# directly instead of guessing.
PUBLIC_BASE_URL = os.environ.get("PUBLIC_BASE_URL", "").rstrip("/")


def public_base_url() -> str:
    return PUBLIC_BASE_URL if PUBLIC_BASE_URL else request.host_url.rstrip("/")


app = Flask(__name__)
work_queue: "queue.Queue[tuple[str,str,str]]" = queue.Queue()

# QC bounds that match whichever DIMS/bitrate this run is actually using —
# in production this is just QC_CONFIG (the real Apple numbers) unmodified.
RUNTIME_QC_CONFIG = dict(QC_CONFIG)
if not USE_FULL_RES:
    RUNTIME_QC_CONFIG["square_resolution"] = DEMO_SQUARE
    RUNTIME_QC_CONFIG["vertical_resolution"] = DEMO_VERTICAL
    RUNTIME_QC_CONFIG["bitrate_range_mbps"] = (RENDER_BITRATE_MBPS * 0.85, RENDER_BITRATE_MBPS * 1.15)
    RUNTIME_QC_CONFIG["duration_range_s"] = (2, 35)

# The "first frame matches source" check exists to catch real bugs (a
# black or broken first frame), calibrated at 0.90 back when only
# `parametric` (zero styling) existed. Now that `stylized`/`cinematic`
# intentionally apply grain/vignette/color-grade/depth-blur to every frame
# including frame 0, comparing against the *raw, unstyled* upload will
# always score lower — that's the style working as intended, not a defect.
# Thresholds below are still real guardrails (a blank/solid frame scores
# near 0 regardless), just calibrated per tier instead of one-size-fits-all.
TIER_FIRST_FRAME_SIMILARITY_MIN = {
    "parametric": 0.90,
    "stylized": 0.55,
    "cinematic": 0.45,
}


def qc_config_for_tier(tier: str) -> dict:
    cfg = dict(RUNTIME_QC_CONFIG)
    cfg["first_frame_similarity_min"] = TIER_FIRST_FRAME_SIMILARITY_MIN.get(tier, 0.90)
    return cfg


def qc_config_for_canvas(tier: str) -> dict:
    """Spotify's own spec, not Apple's — reusing Apple's exact frame-rate
    allow-list here would be wrong (that specific list is an Apple Album
    Motion rule, not something Spotify documents), so this widens it to
    common rates up to a sane ceiling instead. `square_resolution` is
    reused as the single target per run_qc_suite_single's design."""
    cfg = dict(QC_CONFIG)
    cfg["square_resolution"] = CANVAS_DIMS
    cfg["duration_range_s"] = (3, 8)
    cfg["bitrate_range_mbps"] = (CANVAS_BITRATE_MBPS * 0.5, CANVAS_BITRATE_MBPS * 2.5)
    cfg["allowed_frame_rates"] = {24.0, 25.0, 30.0, 60.0}
    cfg["first_frame_similarity_min"] = TIER_FIRST_FRAME_SIMILARITY_MIN.get(tier, 0.90)
    return cfg


def hash_key(raw: str) -> str:
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def require_org():
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        return None, (jsonify({"detail": "expected 'Bearer <api_key>'"}), 401)
    org = db.get_org_by_key_hash(hash_key(auth[len("Bearer "):].strip()))
    if org is None:
        return None, (jsonify({"detail": "invalid or revoked API key"}), 401)
    return org, None


# --- root -------------------------------------------------------------

# --- shared branding (best-effort match to the motion.canvas frontend from
# screenshots — exact colors/fonts not available here, so this approximates
# the dark navy/purple-magenta gradient + lime accent look. Give me the
# actual theme CSS/hex values if you want a pixel-exact match.) ------------

_BRAND_STYLE = """
<meta charset="utf-8">
<style>
  * { box-sizing: border-box; }
  body {
    margin: 0; padding: 3rem 2rem; min-height: 100vh;
    font-family: -apple-system, 'Segoe UI', Inter, sans-serif;
    color: #ece9fb;
    background: linear-gradient(180deg, #0a0812 0%, #170f2e 35%, #3a1548 72%, #7a1f6b 100%);
  }
  .wordmark { font-weight: 700; color: #c9c3f5; text-decoration: none; font-size: 1.1rem; }
  .badge {
    display: inline-block; color: #d3e86a; font-weight: 700; letter-spacing: 0.08em;
    font-size: 0.75rem; text-transform: uppercase; margin-bottom: 1rem;
  }
  h1, h2 { color: #f3f1ff; line-height: 1.15; }
  .card {
    background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.10);
    border-radius: 14px; padding: 1.25rem 1.5rem;
  }
  code { background: rgba(255,255,255,0.08); padding: 2px 7px; border-radius: 5px; font-size: 0.9em; }
  a { color: #b7a7ff; }
  .pill {
    display: inline-block; padding: 0.7rem 1.4rem; border-radius: 999px;
    font-weight: 700; text-decoration: none; margin-right: 0.6rem;
  }
  .pill-primary { background: #d3e86a; color: #1a1a0a; }
  .pill-outline { border: 1px solid rgba(255,255,255,0.35); color: #ece9fb; }
  video { border-radius: 14px; border: 1px solid rgba(255,255,255,0.12); }
</style>
"""


@app.get("/")
def index():
    """Codespaces/Replit's 'Open in Browser' button opens this exact path —
    without a route here it 404s and looks like the whole server is broken,
    when actually every OTHER route was fine. This is that missing route."""
    return f"""
    <html><head><title>motion.canvas — API dev server</title>{_BRAND_STYLE}</head><body>
    <div class="wordmark">motion.canvas</div>
    <div style="margin-top:3rem">
      <div class="badge">Dev server &middot; running</div>
      <h1>It's running.</h1>
      <p style="color:#c7c2e8;max-width:40em">This page itself isn't an endpoint — the API lives under
      <code>/v1/motion-artwork/...</code>, and you talk to it with real HTTP
      requests (curl, or your own code), not by browsing to it directly.</p>
      <div class="card" style="max-width:32em;margin-top:1.5rem">
        <p style="margin:0 0 .5rem">Two links that work directly in a browser:</p>
        <ul style="margin:0;padding-left:1.2rem">
          <li><a href="/v1/health">/v1/health</a> — should show <code>{{"status":"ok"}}</code></li>
          <li><code>/v1/motion-artwork/preview/&lt;job_id&gt;</code> — once a job is
          complete, this plays the result right here.</li>
        </ul>
      </div>
    </div>
    </body></html>
    """


# --- static / asset serving -------------------------------------------

@app.get("/test-assets/cover.png")
def test_cover():
    """Serves the synthetic test cover over real HTTP, so job submission
    exercises a genuine URL download rather than a local-path shortcut."""
    return send_from_directory(os.path.join(ROOT, "test_assets"), "cover_test.png")


@app.get("/v1/motion-artwork/assets/<job_id>/<filename>")
def get_asset(job_id, filename):
    return send_from_directory(os.path.join(ASSETS_DIR, job_id), filename)


@app.get("/v1/motion-artwork/preview/<job_id>")
def preview(job_id):
    """Plays both deliverables inline, styled to sit alongside the
    motion.canvas artist studio rather than looking like a bare dev page —
    exists so you never need to trigger a file download to see whether a
    render worked."""
    job = db.get_job(job_id)
    if job is None or job["status"] != "complete":
        status = job["status"] if job else "not found"
        return f"""<html><head>{_BRAND_STYLE}</head><body>
        <div class="wordmark">motion.canvas</div>
        <div class="card" style="max-width:28em;margin-top:3rem">
          <p style="margin:0">Job <code>{job_id}</code> isn't ready yet — status: <b>{status}</b>.
          Refresh in a few seconds.</p>
        </div></body></html>""", 404

    tier = (job.get("tier") or "parametric").capitalize()
    platform = job.get("platform") or "apple"

    if platform == "spotify_canvas":
        # Single 9:16 deliverable -- job['vertical_asset_url'] is None here
        # (not a pair), so the two-video Apple layout would crash on
        # os.path.basename(None). Real bug, found by actually testing a
        # canvas job through this route rather than assuming the shared
        # template just worked for both platforms.
        body = f"""
        <div class="badge">{tier} tier &middot; Spotify Canvas &middot; ready</div>
        <h2 style="margin-top:.25rem">Your cover, in motion.</h2>
        <p style="color:#c7c2e8">Job <code>{job_id}</code> — no download needed, just watch below.</p>
        <div class="card" style="margin-top:1.5rem;display:inline-block">
          <p style="margin:0 0 .75rem;font-weight:600">Canvas (9:16)</p>
          <video controls autoplay loop muted style="max-width:260px"
            src="/v1/motion-artwork/assets/{job_id}/{os.path.basename(job['square_asset_url'])}"></video>
        </div>"""
    else:
        body = f"""
        <div class="badge">{tier} tier &middot; ready</div>
        <h2 style="margin-top:.25rem">Your cover, in motion.</h2>
        <p style="color:#c7c2e8">Job <code>{job_id}</code> — no download needed, just watch below.</p>
        <div style="display:flex;flex-wrap:wrap;gap:1.5rem;margin-top:1.5rem">
          <div class="card">
            <p style="margin:0 0 .75rem;font-weight:600">Square (1:1)</p>
            <video controls autoplay loop muted style="max-width:340px"
              src="/v1/motion-artwork/assets/{job_id}/{os.path.basename(job['square_asset_url'])}"></video>
          </div>
          <div class="card">
            <p style="margin:0 0 .75rem;font-weight:600">Vertical (3:4)</p>
            <video controls autoplay loop muted style="max-width:280px"
              src="/v1/motion-artwork/assets/{job_id}/{os.path.basename(job['vertical_asset_url'])}"></video>
          </div>
        </div>"""

    return f"""
    <html><head><title>motion.canvas — preview</title>{_BRAND_STYLE}</head><body>
    <div class="wordmark">motion.canvas</div>
    <div style="margin-top:2.5rem">{body}</div>
    </body></html>
    """



@app.get("/v1/health")
def health():
    return jsonify({"status": "ok", "full_res": USE_FULL_RES})


# --- endpoints ----------------------------------------------------------

@app.post("/v1/motion-artwork/jobs")
def create_job():
    org, err = require_org()
    if err:
        return err
    body = request.get_json(force=True)
    for required in ("release_id", "cover_art_url", "callback_url"):
        if required not in body:
            return jsonify({"detail": f"missing field: {required}"}), 422

    tier = body.get("tier", "parametric")
    try:
        price = price_for_tier(tier)
    except ValueError as e:
        return jsonify({"detail": str(e)}), 422

    platform = body.get("platform", "apple")
    if platform not in ("apple", "spotify_canvas"):
        return jsonify({"detail": f"unknown platform: {platform}. Use 'apple' or 'spotify_canvas'."}), 422

    job_id = db.insert_job(
        org_id=org["id"], kind="generate", release_id=body["release_id"],
        artist_id=body.get("artist_id"), cover_art_url=body["cover_art_url"], tier=tier,
        duration_seconds=body.get("duration_seconds"),  # None -> per-platform default in the worker
        style_preset=body.get("style_preset", "subtle_parallax"),
        callback_url=body["callback_url"], metadata=body.get("metadata", {}),
        status="queued", price_usd=price, platform=platform,
    )
    # Captured from THIS request, not a startup-time constant — so the asset
    # URLs the worker builds later match whatever host you actually used to
    # reach the server (127.0.0.1 directly, or a Codespaces/Replit forwarded
    # https://... domain), UNLESS PUBLIC_BASE_URL is set, which always wins.
    work_queue.put((job_id, "generate", public_base_url()))
    return jsonify({
        "job_id": job_id, "status": "queued",
        "estimated_completion_seconds": 20, "tier": tier, "price_usd": price,
    }), 202


@app.get("/v1/motion-artwork/jobs/<job_id>")
def get_job(job_id):
    org, err = require_org()
    if err:
        return err
    job = db.get_job(job_id)
    if job is None or job["org_id"] != org["id"]:
        return jsonify({"detail": "job not found"}), 404

    qc_report = db.get_latest_qc_report(job_id)
    assets = None
    if job["status"] == "complete" and job["square_asset_url"]:
        preview_url = f"{public_base_url()}/v1/motion-artwork/preview/{job_id}"
        if (job.get("platform") or "apple") == "spotify_canvas":
            # Single deliverable -- the right key name, not a borrowed
            # Apple one with a confusing null vertical_3x4 next to it.
            assets = {"canvas_9x16": {"url": job["square_asset_url"]}, "preview_url": preview_url}
        else:
            assets = {
                "square_1x1": {"url": job["square_asset_url"]},
                "vertical_3x4": {"url": job["vertical_asset_url"]},
                "preview_url": preview_url,
            }
    return jsonify({
        "job_id": job_id, "status": job["status"],
        "qc_report": qc_report, "assets": assets,
        "error_message": job.get("error_message"),
    })


@app.post("/v1/motion-artwork/jobs/batch")
def create_batch():
    org, err = require_org()
    if err:
        return err
    body = request.get_json(force=True)
    jobs = body.get("jobs", [])
    if not jobs:
        return jsonify({"detail": "jobs must be non-empty"}), 400
    if len(jobs) > 5000:
        return jsonify({"detail": "max 5000 jobs per batch"}), 400

    batch_id = db.create_batch(org["id"], len(jobs))
    job_ids = []
    for item in jobs:
        tier = item.get("tier", "parametric")
        price = price_for_tier(tier)
        job_id = db.insert_job(
            org_id=org["id"], batch_id=batch_id, kind="generate",
            release_id=item["release_id"], artist_id=item.get("artist_id"),
            cover_art_url=item["cover_art_url"], tier=tier,
            duration_seconds=item.get("duration_seconds", RENDER_DURATION_S),
            style_preset=item.get("style_preset", "subtle_parallax"),
            callback_url=item["callback_url"], metadata=item.get("metadata", {}),
            status="queued", price_usd=price,
        )
        job_ids.append(job_id)
        work_queue.put((job_id, "generate", public_base_url()))

    return jsonify({"batch_id": batch_id, "job_ids": job_ids}), 202


@app.post("/v1/motion-artwork/qc")
def qc_only():
    org, err = require_org()
    if err:
        return err
    body = request.get_json(force=True)
    for required in ("release_id", "square_asset_url", "vertical_asset_url", "source_cover_url"):
        if required not in body:
            return jsonify({"detail": f"missing field: {required}"}), 422

    job_id = db.insert_job(
        org_id=org["id"], kind="qc_only", release_id=body["release_id"],
        cover_art_url=body["source_cover_url"], callback_url=body.get("callback_url"),
        status="queued", price_usd=QC_ONLY_PRICE_USD,
    )
    db.update_job(job_id, square_asset_url=body["square_asset_url"], vertical_asset_url=body["vertical_asset_url"])
    work_queue.put((job_id, "qc_only", public_base_url()))
    return jsonify({"job_id": job_id, "status": "queued", "price_usd": QC_ONLY_PRICE_USD}), 202


# --- background worker ---------------------------------------------------

def _download(url: str, dest: str):
    r = requests.get(url, timeout=30)
    r.raise_for_status()
    with open(dest, "wb") as f:
        f.write(r.content)


def _fire_webhook(job: dict, event: str, qc_report: dict | None, assets: dict | None):
    if not job.get("callback_url"):
        return
    conn = db.get_conn()
    org_row = conn.execute("SELECT * FROM orgs WHERE id = ?", (job["org_id"],)).fetchone()
    conn.close()
    secret = org_row["webhook_secret"] if org_row else ""

    payload = {
        "event": event, "job_id": job["id"], "release_id": job.get("release_id"),
        "status": job["status"], "assets": assets, "qc_report": qc_report,
        "billing": {"price_usd": job.get("price_usd")},
    }
    body = json.dumps(payload).encode("utf-8")
    sig = sign_payload(body, secret)
    try:
        requests.post(
            job["callback_url"], data=body,
            headers={"Content-Type": "application/json", "X-Motion-Artwork-Signature": f"sha256={sig}"},
            timeout=10,
        )
    except requests.RequestException as e:
        print(f"[worker] webhook delivery failed for job {job['id']}: {e}", flush=True)


def process_generate_job(job_id: str, base_url: str):
    db.update_job(job_id, status="processing")
    job = db.get_job(job_id)
    work_dir = os.path.join(ASSETS_DIR, job_id)
    os.makedirs(work_dir, exist_ok=True)
    tier = job.get("tier") or "parametric"
    platform = job.get("platform") or "apple"
    try:
        cover_path = os.path.join(work_dir, "source_cover.png")
        _download(job["cover_art_url"], cover_path)
        estimator = ClassicalDepthEstimator()

        if platform == "spotify_canvas":
            canvas_path = os.path.join(work_dir, "canvas.mp4")
            cover_rgb = cv2.cvtColor(cv2.imread(cover_path), cv2.COLOR_BGR2RGB)
            render_deliverable(
                cover_rgb, estimator, *CANVAS_DIMS,
                duration_s=float(job["duration_seconds"] or CANVAS_DURATION_S),
                fps=RENDER_FPS, out_path=canvas_path, codec="h264",
                bitrate_mbps=CANVAS_BITRATE_MBPS, is_vertical=True, tmp_dir=work_dir, tier=tier,
            )
            db.update_job(job_id, status="qc_review")
            # Reference = the same 9:16 composition with NO styling, so frame 0 is compared
            # like-for-like. Comparing against the raw square cover was the real cause of
            # the first-frame failures (unstyled parametric scored 0.74 that way, 0.995 here).
            ref_path = os.path.join(work_dir, 'canvas_reference.png')
            cv2.imwrite(ref_path, cv2.cvtColor(compose_vertical_canvas(cover_rgb, *CANVAS_DIMS), cv2.COLOR_RGB2BGR))
            report = run_qc_suite_single(canvas_path, ref_path, qc_config_for_canvas(tier))
            db.insert_qc_report(job_id, report["passed"], report["checks"], report["apple_ready"])

            if not report["passed"]:
                db.update_job(job_id, status="rejected", completed_at=db.now())
                job = db.get_job(job_id)
                _fire_webhook(job, "motion_artwork.rejected", report, None)
                return

            canvas_url = f"{base_url}/v1/motion-artwork/assets/{job_id}/canvas.mp4"
            preview_url = f"{base_url}/v1/motion-artwork/preview/{job_id}"
            db.update_job(job_id, status="complete", square_asset_url=canvas_url, completed_at=db.now())
            job = db.get_job(job_id)
            asset_block = {"canvas_9x16": {"url": canvas_url}, "preview_url": preview_url}
            _fire_webhook(job, "motion_artwork.completed", report, asset_block)
            return

        # platform == "apple" (default) — square + vertical pair
        assets = render_pair(
            cover_path, work_dir, estimator,
            duration_s=float(job["duration_seconds"] or RENDER_DURATION_S),
            fps=RENDER_FPS, codec="h264", bitrate_mbps=RENDER_BITRATE_MBPS, dims=DIMS,
            tier=tier,
        )
        db.update_job(job_id, status="qc_review")

        report = run_qc_suite(assets["square_1x1"], assets["vertical_3x4"], cover_path,
                               qc_config_for_tier(tier))
        db.insert_qc_report(job_id, report["passed"], report["checks"], report["apple_ready"])

        if not report["passed"]:
            db.update_job(job_id, status="rejected", completed_at=db.now())
            job = db.get_job(job_id)
            _fire_webhook(job, "motion_artwork.rejected", report, None)
            return

        sq_name = os.path.basename(assets["square_1x1"])
        v_name = os.path.basename(assets["vertical_3x4"])
        sq_url = f"{base_url}/v1/motion-artwork/assets/{job_id}/{sq_name}"
        v_url = f"{base_url}/v1/motion-artwork/assets/{job_id}/{v_name}"
        preview_url = f"{base_url}/v1/motion-artwork/preview/{job_id}"
        db.update_job(job_id, status="complete", square_asset_url=sq_url,
                       vertical_asset_url=v_url, completed_at=db.now())
        job = db.get_job(job_id)
        asset_block = {"square_1x1": {"url": sq_url}, "vertical_3x4": {"url": v_url}, "preview_url": preview_url}
        _fire_webhook(job, "motion_artwork.completed", report, asset_block)

    except Exception as e:
        db.update_job(job_id, status="failed", error_message=str(e)[:2000])
        job = db.get_job(job_id)
        _fire_webhook(job, "motion_artwork.failed", None, None)
        raise


def process_qc_only_job(job_id: str, base_url: str):
    db.update_job(job_id, status="processing")
    job = db.get_job(job_id)
    work_dir = os.path.join(ASSETS_DIR, job_id)
    os.makedirs(work_dir, exist_ok=True)
    try:
        sq = os.path.join(work_dir, "square.mov")
        v = os.path.join(work_dir, "vertical.mov")
        cover = os.path.join(work_dir, "cover.png")
        _download(job["square_asset_url"], sq)
        _download(job["vertical_asset_url"], v)
        _download(job["cover_art_url"], cover)

        report = run_qc_suite(sq, v, cover, RUNTIME_QC_CONFIG)
        db.insert_qc_report(job_id, report["passed"], report["checks"], report["apple_ready"])
        status = "complete" if report["passed"] else "rejected"
        db.update_job(job_id, status=status, completed_at=db.now())
        job = db.get_job(job_id)
        event = "motion_artwork.completed" if report["passed"] else "motion_artwork.rejected"
        _fire_webhook(job, event, report, None)
    except Exception as e:
        db.update_job(job_id, status="failed", error_message=str(e)[:2000])
        job = db.get_job(job_id)
        _fire_webhook(job, "motion_artwork.failed", None, None)
        raise


def worker_loop():
    while True:
        job_id, kind, base_url = work_queue.get()
        try:
            if kind == "generate":
                process_generate_job(job_id, base_url)
            else:
                process_qc_only_job(job_id, base_url)
        except Exception as e:
            print(f"[worker] job {job_id} failed: {e}", flush=True)
        finally:
            work_queue.task_done()


def start_workers(n: int = 2):
    for _ in range(n):
        t = threading.Thread(target=worker_loop, daemon=True)
        t.start()


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 9000
    # Default changed to NOT wipe — a plain restart (e.g. after Ctrl+C or a
    # Codespace reconnect) used to silently delete every org/API key you'd
    # made. Pass MOTION_ARTWORK_FRESH_DB=1 explicitly if you actually want a
    # clean slate (this is what live_demo.py does for its own runs).
    fresh = os.environ.get("MOTION_ARTWORK_FRESH_DB", "0") == "1"
    db.init_db(fresh=fresh)
    start_workers(n=2)
    print(f"[devserver] full_res={USE_FULL_RES} dims={DIMS} listening on 127.0.0.1:{port}", flush=True)
    if PUBLIC_BASE_URL:
        print(f"[devserver] PUBLIC_BASE_URL is set: {PUBLIC_BASE_URL} — returned links will use this", flush=True)
    else:
        print(f"[devserver] PUBLIC_BASE_URL is NOT set — returned links will guess from each request, "
              f"which shows as 'localhost' behind Codespaces and won't open in your browser. "
              f"Put PUBLIC_BASE_URL=https://your-forwarded-address in a .env file to fix this permanently.", flush=True)
    app.run(host="127.0.0.1", port=port, threaded=True)
