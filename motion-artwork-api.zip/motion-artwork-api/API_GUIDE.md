# How the Motion Artwork API Should Function

This describes the intended behavior of the whole system — what a
distributor integrating against it would actually experience. Where the
current build doesn't fully match this yet, that's called out explicitly
rather than glossed over.

## 1. What it does, in one paragraph

A distributor sends a static album cover and a few parameters. The API
generates two short animated video files from it — a square version and a
vertical version, matched to Apple's exact technical requirements — checks
both against Apple's real compliance rules automatically, and hands back
either working files or a clear rejection reason. Nothing about this
requires a human to watch the video and manually judge whether it's good
enough to submit.

## 2. The three tiers — what they mean, honestly

| Tier | Wholesale price | What it's meant to produce | Actually implemented? |
|---|---|---|---|
| `parametric` | $4 (band: $2–8) | Depth-based parallax — the camera subtly pans/dollies over the flat cover using an estimated depth map | **Yes — this is the only one that exists right now.** |
| `stylized` | $14 (band: $10–18) | A richer multi-layer look — separate foreground/background motion, lighting effects | Not built. Currently produces identical output to `parametric`, just billed at the higher price. |
| `cinematic` | $25 (band: $20–30) | Full generative-model output (e.g. via Kling/Runway) for a genuinely cinematic result | Not built. Same situation as `stylized`. |

This is worth being precise about internally: right now, picking a
different `tier` on a job changes what you're charged, not what comes out
the other end. Building real `stylized`/`cinematic` pipelines is future
work (see the original phase plan) — don't demo the price difference to a
distributor as if the visual difference already exists.

## 3. The life of one job, start to finish

```
POST /v1/motion-artwork/jobs
        │
        ▼
   status: queued  ──────────────────────────────┐
        │                                         │  (returned immediately,
        ▼                                         │   202 Accepted — doesn't
  background worker picks it up                   │   wait for rendering)
        │                                         │
        ▼                                         │
 status: processing                               │
  - downloads cover_art_url                        │
  - estimates depth, renders both deliverables      │
        │                                         │
        ▼                                         │
 status: qc_review                                │
  - runs all 22 compliance checks                  │
  (resolution, bitrate, duration, codec, frame      │
   rate, pixel aspect ratio, color profile, no      │
   audio, first-frame match, seamless loop, no      │
   flash/solid frames, safe area — × square         │
   and vertical)                                   │
        │                                         │
   ┌────┴────┐                                    │
   ▼         ▼                                    │
 ALL PASS   ANY FAIL                               │
   │         │                                    │
   ▼         ▼                                    │
complete   rejected          (or: failed, if something
   │         │                broke unexpectedly — a bad
   │         │                download, a crash — separate
   ▼         ▼                from a clean compliance fail)
webhook fired with the outcome, signed ◄───────────┘
```

A **rejected** job is not an error — it's the system correctly refusing to
hand over a file that wouldn't pass Apple's own review. That distinction
matters when you're explaining this to a distributor: rejection is the
product working as intended, not a bug.

## 4. Checking on a job

```
GET /v1/motion-artwork/jobs/<job_id>
```
Returns the current `status`, and once `complete`, the full `qc_report`
(every individual check, pass/fail, with the actual measured numbers) plus
`assets` (`square_1x1`, `vertical_3x4`, and a `preview_url` you can open
directly in a browser — no download required).

## 5. The QC-only endpoint — the low-friction way in

```
POST /v1/motion-artwork/qc
```
Doesn't render anything. Point it at files made some other way (a
freelancer, a different tool, a competitor) plus the original cover, and it
runs the exact same 22 checks against them. Priced at $0.10 — the idea is a
distributor can adopt this alone, with zero commitment to switching who
renders their artwork, which is a much easier sell than the full generation
product.

## 6. Batch endpoint — for catalog backfills

```
POST /v1/motion-artwork/jobs/batch
```
Same job shape, submitted as a list (cap: 5,000 per call), each one
processed independently through the same lifecycle above.

## 7. Webhooks

Fired once, when a job reaches `complete`, `rejected`, or `failed` —
delivered as a `POST` to whatever `callback_url` was given at creation.
Signed with HMAC-SHA256 using the org's own secret, in the
`X-Motion-Artwork-Signature: sha256=<hex>` header, so a distributor's
backend can verify a payload genuinely came from this API and wasn't
spoofed. Payload always includes `event`, `job_id`, `release_id`, `status`,
`assets` (when applicable), `qc_report`, and `billing`.

## 8. Authentication

Every request needs `Authorization: Bearer <api_key>`. Keys belong to an
org, and each org has its own webhook-signing secret — one distributor's
key can never see or affect another's jobs.

## 9. Current state vs. the full vision, plainly

**Fully working, tested end to end:** job creation, the `parametric`
rendering pipeline, all 22 QC checks, the full status lifecycle, signed
webhooks, batch submission, the QC-only endpoint, and API-key auth.

**Not yet built:** distinct `stylized`/`cinematic` rendering (see §2), the
real neural depth model (a classical CPU stand-in is what's actually
running), and the production infrastructure this is designed to graduate
to — Postgres/Celery/Redis/cloud storage in place of the current
SQLite/threads/local-disk dev version.
