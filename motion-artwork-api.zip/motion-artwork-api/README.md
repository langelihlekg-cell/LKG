# Motion Artwork API — Implementation

**New to coding or APIs?** Start with `GETTING_STARTED.md` (normal
computer) or `START_HERE.md` (restricted/school computer, no installs) —
both are hand-holding, zero-assumed-experience walkthroughs. `API_GUIDE.md`
documents how the finished system is meant to behave. This file is the
denser technical reference.

Implements the 5-phase plan: a depth-based parallax renderer, a standalone
Apple-compliance QC suite, and the distributor-facing API layer that wraps
both. Includes a real, running reference server (`devserver/`) — not just
written code — that's been proven end to end with real HTTP traffic.

## The honest constraint, stated once

The original build sandbox had no internet access and no GPU: no
installing FastAPI/Celery/Postgres/Redis/PyTorch, no real Depth Anything V2
weights, no reaching Apple or a real distributor. What *is* possible:
loopback networking works, and Flask + requests + sqlite3 are commonly
already available. So `devserver/` is a same-contract, dependency-light
implementation that actually runs, as real servers, hit with real HTTP
requests. `api/` (FastAPI + Celery + Postgres) remains the documented
production path for when you have network access to install those packages
and run real Postgres/Redis.

## What's real vs. what's a stand-in

**Proven with real HTTP traffic (`python3 devserver/live_demo.py`):**
Two real server processes talking over real loopback HTTP. Job creation →
background worker downloads the cover over HTTP → renders both
deliverables → runs the full QC suite (23 individual checks across
resolution, bitrate, duration, codec, frame rate, pixel aspect ratio, color
profile, audio absence, first-frame match, seamless loop, flash/solid
frames, and safe area) → serves the files back over HTTP → fires a signed
webhook, independently verified by a separate receiver process. Batch
endpoint, QC-only endpoint (tested both passing and correctly rejecting a
broken file), and auth rejection are all covered. Last full run: 18/18
contract-level checks passed.

**Still a stand-in for the real thing:**
`devserver` uses sqlite + Python threads instead of Postgres + Celery/Redis,
and Flask's dev server instead of a production WSGI server — fine for
proving logic, not for real traffic; `api/` is the documented path for
that. `ClassicalDepthEstimator` (classical CPU saliency, not a neural depth
model) is what's running — swapping in `DepthAnythingV2Estimator` needs
`pip install torch transformers` and a weights download, one line of code
but real network + ideally a GPU. Nothing here has touched Apple or a real
distributor account.

## Real bugs found and fixed along the way (worth knowing about)

- **FFmpeg bitrate**: `-minrate`/`-maxrate` need to be *exactly* equal to
  `-b:v` for true CBR — a tolerance band silently falls back to
  content-driven ABR with no error, which can undershoot target bitrate by
  8-10x on low-motion content.
- **`cv2.saliency`**: only ships in `opencv-contrib-python(-headless)`, not
  plain `opencv-python-headless`. Fixed by reimplementing spectral-residual
  saliency directly with numpy's FFT — same published algorithm, no
  non-standard dependency.
- **Codespaces port forwarding**: rewrites the Host header to `localhost`
  regardless of the actual forwarded address used, so auto-detecting a
  public base URL from the incoming request doesn't work reliably behind
  it. Fixed with an explicit `PUBLIC_BASE_URL` (via a `.env` file, loaded
  automatically on startup) that always wins when set.
- **Fresh-DB default**: `devserver/app.py` used to wipe its database by
  default on every restart, silently deleting API keys. Flipped the
  default to preserve data; `live_demo.py` explicitly opts into a clean
  slate for its own automated runs.
- **Apple's frame-rate requirement**: verified against Apple's current
  published guidelines — exactly 23.976/24/25/29.97/30fps, nothing else.
  The original demo path rendered at 12fps for speed, which would fail
  this check; fixed to render at 24fps universally.

## Run it yourself

```bash
pip install flask requests opencv-python-headless numpy scipy pillow
python3 devserver/live_demo.py
```
Starts both servers, runs all 8 test scenarios against real HTTP endpoints,
tears down, prints a pass/fail summary. Takes about 40 seconds.

To run standalone (e.g. to poke it with curl yourself):
```bash
echo 'PUBLIC_BASE_URL=http://127.0.0.1:9000' > .env   # or your Codespace's forwarded address
python3 devserver/app.py 9000 &
python3 devserver/mock_distributor.py 9001 &
python3 devserver/seed_dev_key.py   # prints an org + API key to use
```
Set `MOTION_ARTWORK_FULL_RES=1` before starting `app.py` to render at real
Apple dimensions (3840×3840 / 2048×2732) instead of demo scale — much
slower on CPU, same code path.

## Repo structure

```
generation/     depth estimation + parallax renderer + Dockerfile (GPU worker)
qc/             standalone compliance suite (also the Phase 4 wedge product)
api/            production path: FastAPI, SQLAlchemy, Celery, webhooks, storage, pricing
devserver/      RUNS NOW: Flask + sqlite reference server, mock distributor, live_demo.py
migrations/     Postgres schema (production)
scripts/        week1_prototype.py — standalone CLI, no API needed
tests/          end-to-end pipeline test (generation + QC, no pytest dependency)
docker-compose.yml   local dev stack for api/ (postgres + redis + api + worker)
```

## Phase mapping

| Phase | What it needed | Status |
|---|---|---|
| 1. Manual pipeline validation | depth + parallax script | Built & tested. Submitting real output through your distributor account to a live Apple test release is the one step nothing here can do for you. |
| 2. Core engine + QC suite | containerized worker, compliance engine | Logic built & tested; `generation/Dockerfile` written, not build-tested (needs Docker + network). |
| 3. API gateway, webhooks, sandbox | HTTP API, DB, async jobs, webhook retries | **Running now** via `devserver/`, proven with real HTTP traffic. `api/` is the same contract on production infra, written and syntax-checked, not boot-tested. |
| 4. Distributor pilot, QC-only wedge | `/v1/motion-artwork/qc` at $0.10/check | Implemented and tested both pass and fail paths, live. |
| 5. Enterprise scaling, batch backfills | `/jobs/batch`, serverless GPU | Batch endpoint implemented and tested (5,000 job cap per call); `generation/Dockerfile` is what you'd point RunPod Serverless / Modal at. |

## Pricing

Wholesale tiers (what you bill the distributor) live in `api/pricing.py`
(reused directly by `devserver/app.py`): parametric $4, stylized $14,
cinematic $25 — mid-points of the $2–8 / $10–18 / $20–30 bands — plus the
$0.10 QC-only price. **Only the parametric tier actually renders anything
different right now** — see `API_GUIDE.md` §2 for the honest breakdown.

## Immediate next actions

1. Swap `ClassicalDepthEstimator` for `DepthAnythingV2Estimator` once you
   have GPU + network.
2. Push real output through your own distributor account to a real Apple
   test release.
3. Build genuinely distinct `stylized`/`cinematic` rendering pipelines, or
   stop charging different prices for identical output.
4. When ready for real traffic, move `devserver`'s logic onto `api/`
   rather than scaling Flask's dev server.
