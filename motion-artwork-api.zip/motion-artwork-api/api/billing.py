"""
Stripe billing — usage-based: each successfully COMPLETED job adds a line
item to the org's running Stripe invoice, billed on Stripe's normal cycle
(monthly by default). Rejected/failed jobs are never billed — you don't
pay for a render that didn't pass Apple's compliance checks.

Needs a real Stripe account and API key to actually run — nothing here is
testable without them (same situation as api/storage.py's R2 credentials).
Structure and API calls are correct against Stripe's current SDK; verify
against a Stripe test-mode key before going live.

    pip install stripe
    export STRIPE_SECRET_KEY=sk_test_...
    export STRIPE_WEBHOOK_SECRET=whsec_...   # from the Stripe dashboard,
                                               # after registering the
                                               # endpoint below
"""
import os
import stripe
from sqlalchemy.orm import Session

from .models import Org

stripe.api_key = os.environ.get("STRIPE_SECRET_KEY", "")
STRIPE_WEBHOOK_SECRET = os.environ.get("STRIPE_WEBHOOK_SECRET", "")


def create_stripe_customer(org: Org) -> str:
    """Call once, when an org signs up. Store the returned ID on the org
    row (add a `stripe_customer_id` column — not in the current schema,
    see migrations note at the bottom of this file)."""
    customer = stripe.Customer.create(
        name=org.name,
        metadata={"org_id": str(org.id)},
    )
    return customer.id


def create_setup_intent(stripe_customer_id: str) -> dict:
    """For your frontend: mounts a Stripe Elements card form to collect and
    save a payment method on file, without charging anything yet. Return
    the client_secret to whatever calls this so the frontend can confirm it."""
    intent = stripe.SetupIntent.create(
        customer=stripe_customer_id,
        payment_method_types=["card"],
    )
    return {"client_secret": intent.client_secret}


def record_job_usage(stripe_customer_id: str, job_id: str, tier: str, price_usd: float):
    """Call this exactly once, right when a job's status flips to
    'complete' — not on 'rejected' or 'failed'. Adds a line item to the
    customer's next invoice; Stripe accumulates these and bills on its
    normal cycle rather than charging per-call."""
    stripe.InvoiceItem.create(
        customer=stripe_customer_id,
        amount=round(price_usd * 100),  # Stripe wants integer cents
        currency="usd",
        description=f"Motion artwork — {tier} tier — job {job_id}",
        metadata={"job_id": job_id, "tier": tier},
    )


def verify_webhook(payload: bytes, sig_header: str) -> dict:
    """Call from your /webhooks/stripe route. Raises stripe.error.SignatureVerificationError
    on a bad signature — treat that as a 400, not a 500."""
    return stripe.Webhook.construct_event(payload, sig_header, STRIPE_WEBHOOK_SECRET)


def handle_stripe_event(event: dict, db: Session):
    """Wire this into your webhook route after verify_webhook() succeeds.
    The two events that matter most for a usage-billed API:
      - invoice.paid: the org's monthly bill cleared — nothing to do here
        unless you want to log it or lift a usage cap.
      - invoice.payment_failed: the org's card was declined. This is where
        you'd actually gate access — e.g. pause new job creation for that
        org until it's resolved, rather than silently letting usage pile
        up on a card that isn't working.
    """
    event_type = event["type"]
    obj = event["data"]["object"]

    if event_type == "invoice.payment_failed":
        customer_id = obj["customer"]
        org = db.query(Org).filter(Org.stripe_customer_id == customer_id).first()
        if org:
            # Suggested: add a `billing_status` column ('good' | 'past_due')
            # and check it in api/auth.py's get_current_org() to block new
            # job creation for orgs that are past_due — not implemented
            # here since it needs the schema change noted below first.
            pass

    elif event_type == "invoice.paid":
        pass


# --- schema note -----------------------------------------------------
# This module assumes `orgs` has a `stripe_customer_id` column, which
# migrations/001_init.sql doesn't have yet. Add it:
#
#   ALTER TABLE orgs ADD COLUMN stripe_customer_id TEXT;
#
# and the matching field on api/models.py's Org class:
#
#   stripe_customer_id = Column(Text)
